﻿namespace FarmSystem.Test1
{
    /// <summary>
    /// Enumerator that includes each type of animal.
    /// </summary>
    public enum AnimalType
    {
        Cow,
        Hen,
        Horse,
        Sheep
    }
}

