﻿using System;

namespace FarmSystem.Test1
{
    public class Horse : IAnimal
    {
        public string Id { get; set; }
        public int NoOfLegs { get; set; }
        public Horse()
        {
            Id = Guid.NewGuid().ToString();
            NoOfLegs = 4;
        }
        public void Talk()
        {
            Console.WriteLine("Horse says Neigh!");
        }
        public void Run()
        {
            Console.WriteLine("Horse is running");
        }       
    }
}